package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.addmenu.AddMenuListModel;
import com.example.demo.addmenu.AddMenuModel;
import com.example.demo.addmenu.Addmenu;
import com.example.demo.menuMapper.MenuMapper;
import com.example.demo.registerModel.RegisterModel;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("web")
@Slf4j
public class OrderController {

	@Autowired
	private MenuMapper menuMapper;

	

	// 初期表示画面
	@GetMapping("menu")
	public String menu(@ModelAttribute AddMenuListModel addMenuListModel, Model model) {

		List<Addmenu> customerList = menuMapper.getAllMenuList();
		/*
		 * log.info("==================================================={}",
		 * customerList);
		 */

		addMenuListModel.setAddMenuList(customerList);
		/* log.info("=========={}", addMenuListModel.getAddMenuList().size()); */

		// model.addAttribute("addMenuListModel", addMenuListModel);
		/*
		 * log.info("==================================================={}",
		 * addMenuListModel.getAddMenuList());
		 */
		List<AddMenuModel> allMenuList1 = menuMapper.getAllAddMenuList();

		model.addAttribute("addmenuList", allMenuList1);
		return "menu";
	}

	// 追加のボタン
	@PostMapping("addmenu")
	public String add(@ModelAttribute AddMenuListModel addMenuListModel, Addmenu addmenu, Model model) {

		log.info("================================================" + "{}", addMenuListModel.getAddMenuList());
		// ====================insert========================
		List<Addmenu> customerList = addMenuListModel.getAddMenuList();
		for (int i = 0; i < customerList.size(); i++) {
			Addmenu a = customerList.get(i);

			menuMapper.addmenu(a);
		}

		/* menuMapper.addmenu(addMenuListModel.getAddMenuList()); */
		return "redirect:menu";
	}

	// 削除のボタン

	/*
	 * @PostMapping("delmenu") public String del(Addmenu addmenu, Model model) {
	 * log.info("================================================" + "{}", addmenu);
	 * menuMapper.delmenu(addmenu); return "redirect:menu"; }
	 */

	@PostMapping("record")
	public String record(Addmenu addmenu, Model model) {

		List<AddMenuModel> allMenuList1 = menuMapper.getAllAddMenuList();

		model.addAttribute("addmenuList", allMenuList1);

		// ===== 合計金額を計算するために===============
		
		Integer sum = menuMapper.getSum();
		
		 if (sum == null) {
			 sum = 0;
		}

		 model.addAttribute("intoSum", sum); 
		/*
		 * log.info("================================================" + "{}",
		 * allMenuList1);
		 */
		return "addmenu";
	}
	
	@GetMapping("login")
	public String login(RegisterModel registerMode,Addmenu addmenu,Model model) {
		
		menuMapper.deladdmenu(addmenu);

		return "login";
		
	}

}