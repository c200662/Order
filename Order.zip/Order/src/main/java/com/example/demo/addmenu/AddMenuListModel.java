package com.example.demo.addmenu;

import java.util.List;

import lombok.Data;

@Data
public class AddMenuListModel {

	private String name;
	private List<Addmenu> addMenuList;

	
}
