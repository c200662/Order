package com.example.demo.registerModel;

import lombok.Data;

@Data
public class RegisterModel {

	private String username;

	private String pwd;
}
