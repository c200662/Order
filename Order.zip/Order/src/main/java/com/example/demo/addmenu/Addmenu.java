package com.example.demo.addmenu;

import lombok.Data;

@Data
public class Addmenu {

	private String id;
	private String commodity;
	private int price;
	private int amount;

}
