package com.example.demo.addmenu;

import lombok.Data;

@Data
public class AddMenuModel {
	
	private String id;
	private String commodity;
	private int price;
	private int amount;

}
