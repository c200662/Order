package com.example.demo.menuModel;

import lombok.Data;

@Data
public class MenuModel {
	
	private String id;
	private String commodity;
	private int price;
	private int amount;
}
