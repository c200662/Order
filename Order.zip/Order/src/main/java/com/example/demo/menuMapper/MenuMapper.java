package com.example.demo.menuMapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.addmenu.AddMenuModel;
import com.example.demo.addmenu.Addmenu;
import com.example.demo.registerModel.RegisterModel;

@Mapper
public interface MenuMapper {

	List<Addmenu> getAllMenuList();


	void addmenu(Addmenu a);

	List<AddMenuModel> getAllAddMenuList();


	void delmenu(Addmenu addmenu);
	Integer getSum();


	int checkLogin(RegisterModel registerModel);


	void deladdmenu(Addmenu addmenu);
}
