/*$("#myTable").on('input', '.txtCal', function () {
       var calculated_total_sum = 0;
      
       $("#myTable .txtCal").each(function () {
           var get_textbox_value = $(this).val();
           if ($.isNumeric(get_textbox_value)) {
              calculated_total_sum += parseFloat(get_textbox_value);
              }                  
            });
              $("#total_sum_value").html(calculated_total_sum);
       });*/
       
       
$(document).ready(function () {
    
  				 	// $("#button").on('click', function () {
    	$('form').submit(function() {
					//function checkForm()	{
  	  var pwdvalue = $('#password').val();
  	  var idvalue = $('#id').val();
  				  	//alert(pwdvalue);
    if(  idvalue.length > 0){
  	  				//alert('ok');
  	  if(pwdvalue.length >= 6){
	return true;
}else{
	$('#pshd').show();
	return false;
}
    }else{
  	  $('#hd').show();
  	  alert('空欄です！');
  	  return false;
    }
  });

    
  });
  
  